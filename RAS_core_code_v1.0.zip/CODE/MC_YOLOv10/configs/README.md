# Model configurations

- `proposed/MC-YOLOv10.yaml`: proposed MSL plus CBAM detector used by the training entry point.
- `ablations/YOLOv10-CBAM.yaml` and `ablations/YOLOv10-SEAttention.yaml`: recovered comparison configurations.
- YOLOv10n baseline architecture: `../ultralytics/cfg/models/v10/yolov10n.yaml` (kept at the framework lookup path).

The experiment-specific modules are grouped under `ultralytics/nn/modules/custom/`. The recovered MSL forward path now omits an unused intermediate normalized sum; the returned concatenation path is unchanged. The ablation YAMLs preserve recovered layer definitions and parameters. The SE YAML still passes `reduction=1024`。
