# Ultralytics YOLOv10 detection fork, AGPL-3.0 license

__version__ = "8.1.34"

from ultralytics.models import YOLOv10
from ultralytics.utils import ASSETS, SETTINGS as settings
from ultralytics.utils.downloads import download

__all__ = ("__version__", "ASSETS", "YOLOv10", "download", "settings")
