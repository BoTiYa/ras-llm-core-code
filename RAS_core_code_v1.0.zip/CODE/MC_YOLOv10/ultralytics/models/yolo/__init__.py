# Shared YOLO detection trainer, validator and predictor.

from . import detect

__all__ = ("detect",)
