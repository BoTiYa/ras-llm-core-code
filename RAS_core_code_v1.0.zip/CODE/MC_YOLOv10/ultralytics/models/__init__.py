# YOLOv10 detection package, AGPL-3.0 license

from . import yolo
from .yolov10 import YOLOv10

__all__ = ("yolo", "YOLOv10")
