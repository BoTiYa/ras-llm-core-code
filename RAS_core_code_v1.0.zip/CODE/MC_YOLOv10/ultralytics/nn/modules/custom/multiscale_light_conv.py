# Paper-specific lightweight multiscale convolution module.

import torch
from torch import nn

from ..conv import autopad


class MultiScaleLightConv(nn.Module):
    """轻量化多尺度卷积模块，增强多尺度和小目标检测"""
    def __init__(self, c1, c2, s=1, act=nn.SiLU()):
        super().__init__()
        # 中间通道数减少一半，轻量化
        mid_channels = c2 // 2
        
        # 多尺度分支：3x3 和 5x5 的深度卷积
        self.dw_conv3 = nn.Conv2d(c1, c1, 3, s, autopad(3), groups=c1, bias=False)  # 小尺度
        self.dw_conv5 = nn.Conv2d(c1, c1, 5, s, autopad(5), groups=c1, bias=False)  # 中尺度
        self.dw_bn = nn.BatchNorm2d(c1)  # Retained for recovered checkpoint state-dict compatibility.
        
        # 逐点卷积融合多尺度特征
        self.pw_conv = nn.Conv2d(c1 * 2, mid_channels, 1, 1, 0, bias=False)  # 输入通道翻倍
        self.pw_bn = nn.BatchNorm2d(mid_channels)
        
        # Ghost 生成剩余特征，轻量化
        self.ghost_conv = nn.Conv2d(mid_channels, c2 - mid_channels, 3, 1, 1, groups=mid_channels, bias=False)
        self.ghost_bn = nn.BatchNorm2d(c2 - mid_channels)
        
        self.act = act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        # 多尺度深度卷积
        x3 = self.dw_conv3(x)
        x5 = self.dw_conv5(x)
        
        # 逐点卷积
        x = torch.cat([x3, x5], dim=1)  # Effective multiscale fusion path in the recovered implementation.
        x1 = self.pw_bn(self.pw_conv(x))
        
        # Ghost 生成剩余特征
        x2 = self.ghost_bn(self.ghost_conv(x1))
        
        # 拼接输出
        return self.act(torch.cat([x1, x2], dim=1))

__all__ = ("MultiScaleLightConv",)

