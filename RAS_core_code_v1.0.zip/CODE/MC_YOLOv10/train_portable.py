"""Portable training entry for the packaged YOLOv10 model configurations."""
import argparse
from pathlib import Path
from ultralytics import YOLOv10

HERE = Path(__file__).resolve().parent
DATA = HERE.parent.parent / "01_数据集" / "fish_detection" / "data.yaml"

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train a YOLOv10 configuration from this package.")
    parser.add_argument("--model", default="configs/proposed/MC-YOLOv10.yaml", help="Model YAML, relative to this directory by default.")
    parser.add_argument("--data", default=str(DATA), help="YOLO data YAML; defaults to the packaged fish dataset.")
    parser.add_argument("--name", default=None, help="Run name; defaults to the model YAML stem.")
    parser.add_argument("--device", default=None, help="Device such as 0 or cpu; defaults to framework auto-selection.")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--imgsz", type=int, default=640)
    args = parser.parse_args()

    model_path = Path(args.model)
    if not model_path.is_absolute():
        model_path = HERE / model_path
    run_name = args.name or model_path.stem

    model = YOLOv10(model=str(model_path))
    model.train(
        data=args.data,
        imgsz=args.imgsz,
        epochs=args.epochs,
        batch=args.batch,
        workers=args.workers,
        device=args.device,
        optimizer="SGD",
        lr0=0.01,
        lrf=0.01,
        close_mosaic=10,
        pretrained=True,
        seed=0,
        deterministic=True,
        resume=False,
        project="runs/train",
        name=run_name,
        single_cls=False,
        cache=False,
    )
