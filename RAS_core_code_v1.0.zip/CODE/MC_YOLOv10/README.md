# MC-YOLOv10 code package

This package contains the paper's YOLOv10 fish-detection implementation and the shared training, validation, and prediction framework.

## Folder layout

- `configs/proposed/`: proposed MC-YOLOv10 model configuration.
- `configs/ablations/`: recovered CBAM and SE comparison configurations.
- `ultralytics/cfg/models/v10/`: YOLOv10n baseline YAML at the framework's model lookup path.
- `ultralytics/nn/modules/custom/`: paper-specific MSL convolution, CBAM, and SE modules.
- `ultralytics/models/`, `data/`, `engine/`, and `utils/`: shared detection workflow code.
- `train_portable.py`: entry point using the sibling dataset package at `01_数据集/fish_detection/data.yaml` by default.

## Run

From this directory, install the package in a compatible PyTorch/CUDA environment and run:

```text
pip install -e .
python train_portable.py
```

Use `--model configs/ablations/YOLOv10-CBAM.yaml` or `--model configs/ablations/YOLOv10-SEAttention.yaml` to select a recovered comparison configuration. Pass `--data <path-to-data.yaml>` when the dataset is stored elsewhere.
