# 算法代码

本目录当前包含两个投稿模块：

MC_YOLOv10/为MC-YOLOv10 检测配置、自定义模块，以及 YOLOv10 检测流程所需的框架代码。主配置为`configs/proposed/MC-YOLOv10.yaml`；消融配置位于 `configs/ablations/`。

QLoRA_prototype/为现有 QLoRA 训练原型及依赖列表。

与论文模块的对应情况

- **目标检测：** `MC_YOLOv10/` 提供 MC-YOLOv10 主配置、CBAM/SE 对比配置和检测流程代码。主配置路径为 `MC_YOLOv10/configs/proposed/MC-YOLOv10.yaml`。
- **纹理特征：** 数据包中有 Contrast、Energy、Entropy、Homogeneity 四项特征数据。
- **水质预测：** TCN-Attention 为2个该领域普遍算法模块，可通过公开途径轻易获得，融合方法可查看论文相关结构图。
- **决策模型：** 保留 QLoRA 原型供方法和数据格式参考；
