# QLoRA prototype

`train_qlora_reference.py` is the available QLoRA training prototype. It reads the base model and JSON path from `QWEN_MODEL_PATH` and `INSTRUCTION_JSON`; it does not contain the original machine-specific drive path.

The script defaults to 4-bit NF4, LoRA rank 32/alpha 64/dropout 0.05, batch size 1, gradient accumulation 1 and 50 epochs. The folder `01_数据集/decision_instructions/instruction_examples_20.json` contains 20 example records, not the full 736-sample corpus described in the manuscript.

`requirements_unpinned.txt` records package names. The Qwen3-8B base weights are not included.
