"""Portable QLoRA method prototype; not a verified V3 final training run."""
import json
import torch
import os
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    Trainer,
    TrainingArguments,
    DataCollatorForSeq2Seq, 
    BitsAndBytesConfig
)
from peft import LoraConfig, get_peft_model, TaskType, prepare_model_for_kbit_training

# ================= 配置区域 =================
# 请确认路径无误，建议保留 r"" 前缀防止转义错误
MODEL_ID = os.environ.get("QWEN_MODEL_PATH", "")  
DATA_PATH = os.environ.get("INSTRUCTION_JSON", "")  
OUTPUT_DIR = "./output_qwen3_finetuned"

MAX_LENGTH = 1024        # 上下文长度，设为1024足够养殖指令，也节省显存
batch_size = 1           # 4090开启量化后，batch_size可以开到 4 或 8
gradient_accumulation = 1 
epochs = 50               # 100条数据建议跑10轮，1000条数据跑3轮
save_step = 50           # 每50步保存一次
lr = 2e-4                # QLoRA 推荐学习率
quantification = True    # 【关键修改】必须开启True，否则4090跑不动8B模型训练

# ================= 数据处理函数 (关键修改) =================
def process_func(example):
    """
    专门处理 instruction, input, output 格式的数据
    """
    instruction = example.get("instruction", "")
    input_text = example.get("input", "")
    output_text = example.get("output", "")

    # 1. 构建 Prompt (使用 ChatML 格式)
    # 格式: <|im_start|>system...<|im_start|>user...<|im_start|>assistant...
    if input_text:
        prompt = f"<|im_start|>system\n{instruction}<|im_end|>\n<|im_start|>user\n{input_text}<|im_end|>\n<|im_start|>assistant\n"
    else:
        prompt = f"<|im_start|>system\n{instruction}<|im_end|>\n<|im_start|>user\n(无输入)<|im_end|>\n<|im_start|>assistant\n"
    
    full_text = prompt + output_text + "<|im_end|>"
    
    # 2. Tokenize
    tokenized = tokenizer(
        full_text,
        max_length=MAX_LENGTH,
        padding="max_length",
        truncation=True,
        return_tensors="pt"
    )
    
    input_ids = tokenized.input_ids[0]
    attention_mask = tokenized.attention_mask[0]
    
    # 3. 设置 Labels (将 pad token 设为 -100 以忽略计算 Loss)
    labels = input_ids.clone()
    if tokenizer.pad_token_id is not None:
        labels[labels == tokenizer.pad_token_id] = -100
        
    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "labels": labels
    }

# ================= 主程序流程 =================

if __name__ == "__main__":
    if not MODEL_ID or not DATA_PATH:
        raise SystemExit("Set QWEN_MODEL_PATH and INSTRUCTION_JSON before training. This is an unverified prototype.")
    # 1. 加载 Tokenizer
    print("正在加载 Tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, use_fast=False, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # 2. 加载数据
    print(f"正在加载数据: {DATA_PATH}")
    try:
        ds = Dataset.from_json(DATA_PATH) # 直接读取 JSON
    except Exception as e:
        # 兼容处理：如果文件是 list 格式
        with open(DATA_PATH, 'r', encoding='utf-8') as f:
            data_list = json.load(f)
        ds = Dataset.from_list(data_list)

    # 应用数据处理函数
    print("正在处理数据格式...")
    tokenized_ds = ds.map(process_func, remove_columns=ds.column_names)

    # 3. 加载模型 (集成 QLoRA 配置)
    print("正在加载模型...")
    if quantification:
        # 【关键】4-bit 量化配置
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True
        )
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID,
            quantization_config=bnb_config,
            device_map="auto",
            trust_remote_code=True
        )
        # 预处理模型以支持 k-bit 训练
        model = prepare_model_for_kbit_training(model)
    else:
        # 非量化加载 (4090 跑 8B 会 OOM)
        model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID,
            torch_dtype=torch.bfloat16,
            device_map="auto",
            trust_remote_code=True
        )

    # 开启梯度检查点 (进一步节省显存)
    model.gradient_checkpointing_enable()
    model.enable_input_require_grads()

    # 4. LoRA 配置
    print("配置 LoRA...")
    peft_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        inference_mode=False,
        r=32,            # 增加秩以提升逻辑学习能力
        lora_alpha=64,
        lora_dropout=0.05
    )
    model = get_peft_model(model, peft_config)
    model.print_trainable_parameters()

    # 5. 配置训练参数
    print("配置训练参数...")
    args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        per_device_train_batch_size=batch_size,
        gradient_accumulation_steps=gradient_accumulation,
        logging_steps=1,
        num_train_epochs=epochs,
        save_strategy="steps",
        save_steps=save_step,
        learning_rate=lr,
        save_on_each_node=True,
        gradient_checkpointing=True,
        bf16=True,             # 4090 必须开启 bf16
        fp16=False,
        optim="paged_adamw_32bit", # 使用分页优化器防止显存碎片
        report_to="none"       # 不上传 WandB
    )

    # 6. 开始训练
    print("开始训练...")
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=tokenized_ds,
        data_collator=DataCollatorForSeq2Seq(tokenizer=tokenizer, padding=True),
    )

    trainer.train()
    
    # 7. 保存最终模型
    print(f"训练完成，保存模型到 {OUTPUT_DIR}")
    trainer.save_model(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)
